#GO database setup and usage instructions by Yewei on 20221024:
 
##Instructions:
 
1. Download basic GO ontology (OBO Format) file from http://geneontology.org/docs/download-ontology/

     by $wget -O GO-basic.obo http://purl.obolibrary.org/obo/go/go-basic.obo.

   Use the data version in the header lines of the OBO file to rename the OBO file, for example,

     "data-version: releases/2022-10-07" to rename OBO file as "GO-basic_20221007.obo"

2. Run script "annotate_eggnog_results_go.py" to annotate the GO terms in eggnog-mapper results

     based on python package goatools which reads information in GO database OBO file.

Note:

1. For now, ONLY use old version OBO file "GO-basic_20190417.obo" for annotation in order to avoid

     issues of missing level-1 GO terms.
