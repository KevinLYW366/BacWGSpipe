#KEGG reference pathway database setup and usage instructions by Yewei on 20221017:

##Example item: 

  pathway_ID,pathway_level1,pathway_level2,pathway_level3: map01100,Metabolism,Global and overview maps,Metabolic pathways
 
##Instructions:
 
1. Download json file from https://www.genome.jp/kegg-bin/get_htext?org_name=br08901&htext=br08901.keg&hier=2 (reference pathway) and 

     save it as "KEGG_pathway_maps_<date>.json".

2. Download links between KEGG pathway and KOs (KEGG orthology) by $wget -O KEGG_link_pathway_ko_<date>.txt https://rest.kegg.jp/link/pathway/ko to

     save it as "KEGG_link_pathway_ko_<date>.txt".

3. Run script "KEGG_reference_pathway_database.py" to set up KEGG reference pathway database "KEGG_pathway_maps_<date>.txt".

##Note:

1. Link pathway IDs to KOs (KEGG orthology)): https://rest.kegg.jp/link/pathway/ko.

2. Link KEGG orthology (ko) to gene IDs of a certain organism: https://rest.kegg.jp/link/ko/<org>. <org> = KEGG organism code