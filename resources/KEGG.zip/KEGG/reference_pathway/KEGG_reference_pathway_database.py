#!/home/lyw/software/anaconda3/bin/python

####################################################
# Script to set up KEGG reference pathway database #
# by Yewei on 20221017                             #
####################################################

# Load library
import pandas as pd
import json
import sys

# Input
# links between KEGG pathway and KOs (txt)
link_path_ko_txt = sys.argv[1]
# KEGG pathway maps (json)
path_maps_js = sys.argv[2]
# date format: yyyymmdd (20221017)
date = sys.argv[3]

# Load links between KEGG pathway and KOs (txt) to a dictionary
link_path_ko_dict = {}
with open(link_path_ko_txt, 'r') as t:
    buf = t.readline()
    while buf:
        items = buf.strip().split("\t")
        ko = items[0].replace("ko:", "")
        path = items[1].replace("path:", "")
        # only extract pathway ID starting with "map"
        if "map" in path:
            if path not in link_path_ko_dict:
                link_path_ko_dict[path] = [ko]
            else:
                if ko not in link_path_ko_dict[path]:
                    link_path_ko_dict[path].append(ko)
        buf = t.readline()

# Parse KEGG pathway maps (json)
with open(path_maps_js, 'r') as j:
    path_maps_data = json.load(j)

# Output data to KEGG pathway database (txt)
outfile = "KEGG_reference_pathway_database_{}.txt".format(str(date))
with open(outfile, 'w') as fout:
    header = "{}\t{}\t{}\t{}\t{}\n".format("pathway_ID", "pathway_level1", "pathway_level2",
                                           "pathway_level3", "identified_KOs")
    fout.write(header)
    for l1 in path_maps_data["children"]:
        level1 = l1["name"]
        for l2 in l1["children"]:
            level2 = l2["name"]
            for l3 in l2["children"]:
                map_id = "map" + l3["name"].split("  ")[0]
                level3 = l3["name"].split("  ")[1]
                # some pathway IDs might not have corresponding KOs
                if map_id in link_path_ko_dict:
                    kos = link_path_ko_dict[map_id]
                else:
                    kos = []
                pathway = "{}\t{}\t{}\t{}\t{}\n".format(map_id, level1, level2, level3, ';'.join(kos))
                fout.write(pathway)
